import { defineConfig } from '@playwright/test';

export default defineConfig({
    use: {
        baseURL: 'https://example.com',
        headless: true,
    },
    reporter: [['list'], ['allure-playwright']],
});
