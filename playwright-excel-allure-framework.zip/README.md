# Playwright Excel Data-Driven Framework

## Features
- Page Object Model structure
- Excel-based data-driven tests
- Environment configuration
- Allure reporting

## Commands
```bash
npm install
npx playwright test
npm run allure:generate
npm run allure:open
```
